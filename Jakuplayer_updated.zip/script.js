document.addEventListener('DOMContentLoaded', ()=> {
  const audio = document.getElementById('audio');
  const widget = document.getElementById('player-widget');
  const playBtn = document.getElementById('playPause');
  const prevBtn = document.getElementById('prev');
  const nextBtn = document.getElementById('next');
  const seek = document.getElementById('seek');
  const currentTimeEl = document.getElementById('currentTime');
  const durationEl = document.getElementById('duration');

  function updateVisibility() {
    const hasSource = !!(audio.currentSrc || audio.querySelector('source')?.src);
    widget.classList.toggle('player-visible', hasSource);
    widget.classList.toggle('player-hidden', !hasSource);
  }
  updateVisibility();

  audio.addEventListener('loadedmetadata', ()=>{
    const dur = audio.duration || 0;
    durationEl.textContent = formatTime(dur);
    seek.max = Math.floor(dur);
  });

  audio.addEventListener('timeupdate', ()=>{
    seek.value = Math.floor(audio.currentTime);
    currentTimeEl.textContent = formatTime(audio.currentTime);
  });

  seek.addEventListener('input', ()=> {
    audio.currentTime = seek.value;
    currentTimeEl.textContent = formatTime(seek.value);
  });

  playBtn.addEventListener('click', ()=>{
    if (audio.paused) {
      audio.play();
      playBtn.textContent = '⏸️';
    } else {
      audio.pause();
      playBtn.textContent = '▶️';
    }
  });

  prevBtn.addEventListener('click', ()=>{
    audio.currentTime = Math.max(0, audio.currentTime - 10);
  });
  nextBtn.addEventListener('click', ()=>{
    audio.currentTime = Math.min(audio.duration || 0, audio.currentTime + 10);
  });

  function formatTime(sec){
    if (!sec || isNaN(sec)) return '0:00';
    sec = Math.floor(sec);
    const m = Math.floor(sec / 60);
    const s = sec % 60;
    return `${m}:${s.toString().padStart(2,'0')}`;
  }

  const obs = new MutationObserver(updateVisibility);
  obs.observe(audio, {attributes:true, childList:true, subtree:true});
});
